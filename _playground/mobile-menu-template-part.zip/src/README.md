# Mobile Menu Template Part Block

You can [test the block in your browser](https://playground.wordpress.net/?blueprint-url=https://raw.githubusercontent.com/colinduwe/mobile-menu-template-part/main/_playground/blueprint.json) using Playground. Try adding the Menu Menu block to a Navigation block and configure a menu template in the Settings Sidebar.
